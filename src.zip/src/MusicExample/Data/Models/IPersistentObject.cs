﻿namespace UserApi.Data.Models
{
    public interface IPersistentObject
    {
        int Id { get; }
    }
}
