﻿namespace UserApi.Models
{
    public class Band
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}